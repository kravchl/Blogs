# iOS Landing Page

> Landing page template for iOS apps

<a href="https://sindresorhus.com/ios-landing-page/">
	<img src="https://cloud.githubusercontent.com/assets/170270/25322567/63133754-28e2-11e7-931b-cb791b798708.png" width="1277">
</a>


## License

[CC0](https://creativecommons.org/publicdomain/zero/1.0/)
